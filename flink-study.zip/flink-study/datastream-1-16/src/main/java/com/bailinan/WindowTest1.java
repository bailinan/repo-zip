package com.bailinan;

import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;

import java.time.Duration;

public class WindowTest1 {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStream<WindowEvent> events = env.addSource(new DataSourceCreator<>(new WindowEvent.DataSupplier(), 200), TypeInformation.of(WindowEvent.class))
                .assignTimestampsAndWatermarks(
                        WatermarkStrategy.<WindowEvent>forBoundedOutOfOrderness(Duration.ofSeconds(2)).withTimestampAssigner((event, time) -> event.timestamp)
                );
        SingleOutputStreamOperator<WindowEvent> reduce = events.keyBy(it -> it.name)
                .window(TumblingEventTimeWindows.of(Time.seconds(2)))
                .reduce((it1, it2) -> {
                    it1.score = it1.score + it2.score;
                    return it1;
                });
        reduce.addSink(new CommonSink<>());
        env.execute();
    }
}
