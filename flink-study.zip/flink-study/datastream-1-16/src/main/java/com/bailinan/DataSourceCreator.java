package com.bailinan;

import org.apache.flink.streaming.api.functions.source.FromIteratorFunction;

import java.io.Serializable;
import java.util.Iterator;
import java.util.function.Supplier;

public class DataSourceCreator<T> extends FromIteratorFunction<T> {

    public DataSourceCreator(Supplier<T> generator, long delay) {
        super(new DataIterator<>(generator, delay));
    }

    public static class DataIterator<T> implements Iterator<T> , Serializable {
        private final Supplier<T> generator;
        private final long delay;

        public DataIterator(Supplier<T> generator, long delay) {
            this.generator = generator;
            this.delay = delay;
        }

        @Override
        public boolean hasNext() {
            return true;
        }

        @Override
        public T next() {
            try {
                Thread.sleep(delay);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            return generator.get();
        }
    }
}
