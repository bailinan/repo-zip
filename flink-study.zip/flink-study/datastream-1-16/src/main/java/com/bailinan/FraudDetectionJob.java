package com.bailinan;

import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;
import org.apache.flink.walkthrough.common.entity.Alert;
import org.apache.flink.walkthrough.common.entity.Transaction;
import org.apache.flink.walkthrough.common.sink.AlertSink;
import org.apache.flink.walkthrough.common.source.TransactionSource;

import java.io.IOException;

public class FraudDetectionJob {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStream<Transaction> transactions = env.addSource(new TransactionSource()).name("transactions");

        DataStream<Alert> alert = transactions.keyBy(Transaction::getAccountId).process(new FraudDetector()).name("fraud-detector");

        alert.addSink(new AlertSink()).name("send-alerts");

        env.execute("Fraud Detection");
    }

    public static class FraudDetector extends KeyedProcessFunction<Long, Transaction, Alert> {
        private static final double LARGE_AMOUNT = 500d;
        private static final double SMALL_AMOUNT = 1d;
        private static final long ONE_MINUTE = 60 * 1000L;

        private ValueState<Boolean> flagState;
        private ValueState<Long> timerState;

        @Override
        public void open(Configuration parameters) throws Exception {
            super.open(parameters);
            ValueStateDescriptor<Boolean> flagDescriptor = new ValueStateDescriptor<>("flag", Boolean.class);
            flagState = getRuntimeContext().getState(flagDescriptor);

            ValueStateDescriptor<Long> timerDescriptor = new ValueStateDescriptor<>("timer", Long.class);
            timerState = getRuntimeContext().getState(timerDescriptor);
        }

        @Override
        public void processElement(Transaction value, Context ctx, Collector<Alert> out) throws Exception {
            if (flagState.value() != null) {
                if (value.getAmount() > LARGE_AMOUNT) {
                    Alert alert = new Alert();
                    alert.setId(value.getAccountId());
                    out.collect(alert);
                }
                cleanUp(ctx);
            }
            if (value.getAmount() < SMALL_AMOUNT) {
                flagState.update(true);

                long timer = ctx.timerService().currentProcessingTime() + ONE_MINUTE;
                ctx.timerService().registerEventTimeTimer(timer);
                timerState.update(timer);
            }
        }

        @Override
        public void onTimer(long timestamp, OnTimerContext ctx, Collector<Alert> out) throws Exception {
            super.onTimer(timestamp, ctx, out);
            timerState.clear();
            flagState.clear();
        }

        private void cleanUp(Context ctx) throws IOException {
            Long timer = timerState.value();
            ctx.timerService().deleteProcessingTimeTimer(timer);

            timerState.clear();
            flagState.clear();
        }
    }
}
