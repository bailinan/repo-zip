package com.bailinan;

import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.co.RichCoFlatMapFunction;
import org.apache.flink.util.Collector;

public class StreamConnect {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStream<String> controlStream = env.fromElements("DROP", "IGNORE", "IGNORE2")
                .keyBy(it -> it);

        DataStream<String> dataStream = env.fromElements("Apache", "DROP", "Flink", "IGNORE")
                .keyBy(it -> it);

        controlStream.connect(dataStream)
                .flatMap(new ControlFunction())
                .addSink(new CommonSink<>());

        env.execute();
    }

    public static class ControlFunction extends RichCoFlatMapFunction<String, String, String> {
        private ValueState<Boolean> blocked;

        @Override
        public void open(Configuration parameters) throws Exception {
            super.open(parameters);
            blocked = getRuntimeContext().getState(new ValueStateDescriptor<Boolean>("blocked", Boolean.class));
        }

        @Override
        public void flatMap1(String value, Collector<String> out) throws Exception {
            blocked.update(true);
        }

        @Override
        public void flatMap2(String value, Collector<String> out) throws Exception {
            if (blocked.value() == null) {
                out.collect(value);
            }
        }
    }
}
