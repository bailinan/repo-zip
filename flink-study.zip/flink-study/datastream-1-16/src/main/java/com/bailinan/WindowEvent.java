package com.bailinan;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.function.Supplier;

public class WindowEvent implements Serializable {
    public int id;
    public String name;
    public Long timestamp;
    public int score;

    public WindowEvent(int id, String name, Long timestamp) {
        this.id = id;
        this.name = name;
        this.timestamp = timestamp;
    }

    public static class DataSupplier implements Supplier<WindowEvent>, Serializable {
        private int previousId = 0;
        private long previousTime = LocalDateTime.now().withMinute(0).withSecond(0).toInstant(ZoneOffset.of("+8")).toEpochMilli();
        @Override
        public WindowEvent get() {
            WindowEvent windowEvent = new WindowEvent(previousId++, "bailinan0", previousTime);
            if (previousId % 13 == 0) {
                windowEvent.timestamp = windowEvent.timestamp - 1299;
            }
            windowEvent.score = 1;
            previousTime += 200;
            return windowEvent;
        }
    }

    @Override
    public String toString() {
        return "WindowEvent{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", timestamp=" + timestamp +
                ", score=" + score +
                '}';
    }
}
