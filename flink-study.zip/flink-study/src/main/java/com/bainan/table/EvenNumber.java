package com.bainan.table;

import org.apache.flink.table.api.DataTypes;
import org.apache.flink.table.catalog.DataTypeFactory;
import org.apache.flink.table.functions.ScalarFunction;
import org.apache.flink.table.types.inference.TypeInference;

import java.util.Optional;

public class EvenNumber extends ScalarFunction {

    public Long eval(Long input) {
        return input % 2;
    }
}
