package com.bainan.table;

import org.apache.flink.configuration.ConfigOption;
import org.apache.flink.streaming.connectors.kafka.table.KafkaDynamicTableFactory;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.TableEnvironment;

import java.util.Set;
import java.util.stream.Collectors;

public class TableSqlExample {
    public static void main(String[] args) {
        EnvironmentSettings settings = EnvironmentSettings.newInstance()
                .useBlinkPlanner()
                .inStreamingMode()
                .build();
        TableEnvironment env = TableEnvironment.create(settings);

        demoTest(env);
    }

    private static void demoTest(TableEnvironment env) {
        env.createTemporarySystemFunction("evenNumber", EvenNumber.class);
        env.createTemporarySystemFunction("StringLength", StringLength.class);

        env.executeSql(
                "create table user_behavior (" +
                        " user_id BIGINT," +
                        " item_id BIGINT," +
                        " category_id BIGINT," +
                        " behavior STRING," +
                        " ts TIMESTAMP(3)" +
                        " ) WITH ( " +
                        " 'connector' = 'datagen', " +
                        " 'rows-per-second' = '1' " +
                        " ) "
        );

        env.executeSql(
                "create table sink_user_behavior (" +
                        " sink_name STRING," +
                        " user_id BIGINT," +
                        " item_id BIGINT," +
                        " behavior STRING," +
                        " even_number BIGINT," +
                        " behavior_length INT," +
                        " ts TIMESTAMP(3)" +
                        " ) WITH ( " +
                        " 'connector' = 'print' " +
                        " ) "
        );

        env.executeSql(
                "create table sink_user_behavior2 (" +
                        " sink_name STRING," +
                        " user_id BIGINT," +
                        " item_id BIGINT," +
                        " behavior STRING," +
                        " even_number BIGINT," +
                        " behavior_length INT," +
                        " ts TIMESTAMP(3)" +
                        " ) WITH ( " +
                        " 'connector' = 'print' " +
                        " ) "
        );

        Table result = env.sqlQuery("select 'sink_user_behavior' as `sink_name`, user_id, item_id, behavior, evenNumber(item_id) as even_number, StringLength(behavior) as behavior_length, ts  from user_behavior");
        Table result2 = env.sqlQuery("select 'sink_user_behavior2' as `sink_name`, user_id, item_id, behavior, evenNumber(item_id) as even_number, StringLength(behavior) as behavior_length, ts  from user_behavior");

        result.executeInsert("sink_user_behavior");
        result2.executeInsert("sink_user_behavior2");
    }


    private static void filesystemTest(TableEnvironment env) {
        env.executeSql("create table clickTable (" +
                " username STRING, " +
                " url STRING, " +
                " ts BIGINT " +
                ") WITH ( " +
                " 'connector' = 'filesystem', " +
                " 'path' = 'input/click.txt', " +
                " 'format' = 'csv'" +
                " ) ");

        env.executeSql("create table outTable (" +
                " username STRING, " +
                " url STRING " +
                ") WITH ( " +
                " 'connector' = 'filesystem', " +
                " 'path' = 'output', " +
                " 'format' = 'csv' " +
                " ) ");

        Table result = env.sqlQuery(" select username, url from clickTable where username = 'Mary'");

        result.executeInsert("outTable");
    }
}
