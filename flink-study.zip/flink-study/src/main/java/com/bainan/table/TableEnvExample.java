package com.bainan.table;

import org.apache.flink.configuration.ConfigOption;
import org.apache.flink.connector.jdbc.table.JdbcDynamicTableFactory;
import org.apache.flink.streaming.connectors.kafka.table.KafkaDynamicTableFactory;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.TableEnvironment;

import java.util.Set;
import java.util.stream.Collectors;

public class TableEnvExample {
    public static void main(String[] args) {
        EnvironmentSettings settings = EnvironmentSettings.newInstance()
                .useBlinkPlanner()
                .inStreamingMode()
                .build();
        TableEnvironment env = TableEnvironment.create(settings);

//        filesystemTest(env);
        mysqlTest(env);
//        jdbcOptions();
    }

    private static void jdbcOptions() {
//        JdbcDynamicTableFactory jdbcDynamicTableFactory = new JdbcDynamicTableFactory();
//        Set<String> require = jdbcDynamicTableFactory.requiredOptions().stream().map(ConfigOption::key).collect(Collectors.toSet());
//        Set<String> options = jdbcDynamicTableFactory.optionalOptions().stream().map(ConfigOption::key).collect(Collectors.toSet());
//        System.out.print("x");

        KafkaDynamicTableFactory kafka = new KafkaDynamicTableFactory();
        Set<String> require = kafka.requiredOptions().stream().map(ConfigOption::key).collect(Collectors.toSet());
        Set<String> options = kafka.optionalOptions().stream().map(ConfigOption::key).collect(Collectors.toSet());
        System.out.print("x");
    }

    private static void mysqlTest(TableEnvironment env) {
        env.executeSql("CREATE TABLE RiskGrade ( " +
                "  id STRING, " +
                "  grade_code STRING, " +
                "  min_wd STRING, " +
                "  max_wd STRING, " +
                "  PRIMARY KEY (id) NOT ENFORCED " +
                ") WITH ( " +
                "   'connector' = 'jdbc', " +
                "   'url' = 'jdbc:mysql://139.196.41.243:3306/¬flood_warning_business', " +
                "   'table-name' = 't_risk_grade', " +
                "   'username' = 'root', " +
                "   'password' = '9111=hot' " +
                ")");

        env.executeSql("CREATE TABLE OutRiskGrade ( " +
                "  id STRING, " +
                "  grade_code STRING, " +
                "  min_wd STRING, " +
                "  max_wd STRING " +
                ") WITH ( " +
                " 'connector' = 'filesystem', " +
                " 'path' = 'output', " +
                " 'format' = 'csv' " +
                " ) ");
        Table result = env.sqlQuery("select * from RiskGrade");

        result.executeInsert("OutRiskGrade");
    }

    private static void filesystemTest(TableEnvironment env) {
        env.executeSql("create table clickTable (" +
                " username STRING, " +
                " url STRING, " +
                " ts BIGINT " +
                ") WITH ( " +
                " 'connector' = 'filesystem', " +
                " 'path' = 'input/click.txt', " +
                " 'format' = 'csv'" +
                " ) ");

        env.executeSql("create table outTable (" +
                " username STRING, " +
                " url STRING " +
                ") WITH ( " +
                " 'connector' = 'filesystem', " +
                " 'path' = 'output', " +
                " 'format' = 'csv' " +
                " ) ");

        Table result = env.sqlQuery(" select username, url from clickTable where username = 'Mary'");

        result.executeInsert("outTable");
    }
}
